package com.openclassrooms.medi_labo.api_3_risque;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Api3RisqueApplication {

	public static void main(String[] args) {
		SpringApplication.run(Api3RisqueApplication.class, args);
	}

}
