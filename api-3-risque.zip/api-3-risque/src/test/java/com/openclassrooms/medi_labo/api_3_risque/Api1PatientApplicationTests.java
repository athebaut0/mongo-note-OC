package com.openclassrooms.medi_labo.api_3_risque;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Api1PatientApplicationTests {

	@Test
	void contextLoads() {
	}

}
