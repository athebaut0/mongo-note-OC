package com.openclassrooms.medi_labo.front.config;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.openclassrooms.medi_labo.front.model.Patient;

@FeignClient(name = "gateway", url = "http://localhost:8086")
public interface GatewayClient {

    //////////// PATIENT-SERVICE/////////////
//    @GetMapping(value = "/api-1-patient/{id}")
//    Patient getPatient(@PathVariable("id") int id);

//    @GetMapping(value = "/api-1-patient")
//    Patient getPatient(@RequestParam String firstName, @RequestParam String lastName);

    @GetMapping(value = "/api-1-patient/")
    List<Patient> getPatients();

//    @PostMapping(value = "/api-1-patient")
//    void savePatient(Patient patientDto);
//
//    @PutMapping(value = "/api-1-patient")
//    void updatePatient(Patient patientDto);
//
//    @DeleteMapping(value = "/api-1-patient/{id}")
//    void deletePatient(@PathVariable("id") int id);
//
//
//    ////////////NOTE-SERVICE/////////////
//    @GetMapping(value = "/note/patient/{id}")
//    List<Note> getNotesByPatientId(@PathVariable("id") int id);
//
//    @GetMapping(value = "/note/{id}")
//    Note getNoteById(@PathVariable("id") String id);
//
//    @PostMapping(value = "/note")
//    void createNote(Note note);
//
//    @PutMapping(value = "/note")
//    void updateNote(Note note);
//
//    @DeleteMapping(value = "/note/{id}")
//    void deleteNote(@PathVariable("id") String id);
//
////    @DeleteMapping(value = "/note/patient/{id}")
////    void deleteNoteByPatientId(@PathVariable("id") int id);
//
//
//    ////////////DIABETES-ASSESSMENT-SERVICE/////////////
//    @GetMapping(value = "/assessment/{id}")
//    String patientDiabetesAssessment(@PathVariable("id") int patientId);
}