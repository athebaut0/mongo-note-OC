package com.openclassrooms.medi_labo.api_1_patient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Api1PatientApplication {

	public static void main(String[] args) {
		SpringApplication.run(Api1PatientApplication.class, args);
	}

}
